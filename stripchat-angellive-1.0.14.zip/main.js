(function () {
  "use strict";

  var API_BASES = ["https://zh.stripchat.global", "https://stripchat.com"];
  var REFERER = "https://zh.stripchat.global/";
  var UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36";
  var PAGE_SIZE = 30;

  // Stripchat 的 HLS 现在受 Mouflon v2 保护：媒体清单必须带 psch/pkey 才返回真清单，
  // 且真清单里的分片文件名是加密的。宿主播放器没有解密能力，必须由解密代理还原成标准 HLS。
  //
  // 所有设备统一只走云端 Cloudflare Worker：
  //   - 手机 / 平板 / Mac 行为一致，出问题只看一处日志；
  //   - 不依赖任何一台自己的机器开着机（本地进程只在 Mac 上，且出网要绕节点）；
  //   - PROXY_HOSTS 留成数组是为了将来加备用 Worker，按顺序探测、命中后缓存。
  // 想临时回退到 Mac 本地节点（~/stripchat-mouflon-proxy，127.0.0.1:8787），
  // 把 { base: "http://127.0.0.1:8787", timeout: 2 } 加回数组最前面即可。
  var PROXY_HOSTS = [
    { base: "https://stripchat-mouflon-proxy.douyin-skip-community.workers.dev", timeout: 10 }
  ];
  var proxyBaseCache = null;

  // 解析超时是"加载太久直接闪退"的主因：宿主对 getPlayback 有整体超时，
  // 之前最坏情况会串行等 2 + 10 + 2 秒探测代理、再串行等 3×10 秒直连上游，
  // 加起来 40 秒以上。这里给整个解析过程加一个硬上限，并给失败的流做短缓存，
  // 避免用户反复点击时每次都重跑一遍完整探测。
  var RESOLVE_DEADLINE_MS = 12000;
  var FAIL_TTL_MS = 8000;
  var failureCache = {};

  function firstSuccess(tasks, fallback) {
    return new Promise(function (resolve, reject) {
      if (!tasks.length) { reject(fallback); return; }
      var pending = tasks.length;
      var last = fallback || null;
      tasks.forEach(function (task) {
        Promise.resolve().then(task).then(resolve, function (error) {
          if (error) last = error;
          pending -= 1;
          if (pending === 0) reject(last || fallback);
        });
      });
    });
  }

  function withDeadline(promise, ms, message) {
    // 宿主若没有 setTimeout 就退化成不加超时，绝不因为兜底逻辑本身抛错。
    if (typeof setTimeout !== "function") return promise;
    var timer = null;
    var guard = new Promise(function (_, reject) {
      timer = setTimeout(function () {
        reject(Host.makeError("TIMEOUT", message, {}));
      }, ms);
    });
    return Promise.race([promise, guard]).then(function (value) {
      if (timer) clearTimeout(timer);
      return value;
    }, function (error) {
      if (timer) clearTimeout(timer);
      throw error;
    });
  }

  var CATEGORIES = [
    { id: "girls", title: "女主播", icon: "person.crop.circle", tag: "girls" },
    { id: "girls/new", title: "最新女主播", icon: "sparkles", tag: "girls/new" },
    { id: "girls/asian", title: "亚洲女主播", icon: "globe.asia.australia", tag: "girls/asian" },
    { id: "couples", title: "情侣直播", icon: "person.2", tag: "couples" },
    { id: "men", title: "男主播", icon: "person.crop.circle", tag: "men" }
  ];

  function headers(accept) {
    return {
      "User-Agent": UA,
      "Referer": REFERER,
      "Origin": "https://zh.stripchat.global",
      "Accept": accept,
      "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
      "X-Requested-With": "XMLHttpRequest"
    };
  }

  function apiHeaders() { return headers("application/json, text/plain, */*"); }
  function hlsHeaders() { return headers("application/vnd.apple.mpegurl, application/x-mpegURL, */*"); }
  function playbackHeaders() {
    return {
      "User-Agent": UA,
      "Accept": "application/vnd.apple.mpegurl, application/x-mpegURL, */*"
    };
  }

  async function get(url, requestHeaders, timeout) {
    var response = await Host.http.request({
      request: { url: url, method: "GET", headers: requestHeaders || {}, timeout: timeout || 20 }
    });
    if (!response || Number(response.status || 0) >= 400) {
      throw Host.makeError("UPSTREAM", "HTTP " + String(response && response.status || 0), { url: url });
    }
    return String(response.bodyText || "");
  }

  async function getJSON(url, timeout) {
    var text = await get(url, apiHeaders(), timeout || 20);
    if (/<html[\s>]|cloudflare|cf-chl-|just a moment|access denied/i.test(text)) {
      throw Host.makeError("UPSTREAM", "Stripchat 返回了访问拦截页", { url: url });
    }
    try { return JSON.parse(text); }
    catch (_) { throw Host.makeError("PARSE", "Stripchat API 返回了无效 JSON", { url: url }); }
  }

  async function currentAPI(path, timeout) {
    var last = null;
    for (var i = 0; i < API_BASES.length; i += 1) {
      try { return await getJSON(API_BASES[i] + path, timeout); }
      catch (error) { last = error; }
    }
    throw last || Host.makeError("NETWORK", "Stripchat API 请求失败", { path: path });
  }

  function payload(value) {
    if (Array.isArray(value)) return { models: value };
    if (!value || typeof value !== "object") return {};
    if (Array.isArray(value.models) || Array.isArray(value.blocks)) return value;
    if (value.data !== undefined) return payload(value.data);
    if (value.body !== undefined) return payload(value.body);
    if (value.result !== undefined) return payload(value.result);
    return value;
  }

  function normalizeModel(model) {
    if (!model || typeof model !== "object") return model;
    var nested = model.user && model.user.user && typeof model.user.user === "object"
      ? model.user.user : model.model && typeof model.model === "object" ? model.model : null;
    if (!nested) return model;
    var result = {};
    Object.keys(model).forEach(function (key) { result[key] = model[key]; });
    Object.keys(nested).forEach(function (key) { result[key] = nested[key]; });
    return result;
  }

  function publicLive(model) {
    var status = String(model && model.status || "").toLowerCase();
    return (!status || status === "public") && model.isLive !== false && model.isOnline !== false;
  }

  function absoluteImage(value) {
    var text = String(value || "").trim();
    return text.indexOf("//") === 0 ? "https:" + text : text;
  }

  function roomDTO(model) {
    model = normalizeModel(model || {});
    var username = String(model.username || model.name || model.nickname || "未命名主播");
    var modelId = String(model.id !== undefined ? model.id : model.modelId || "");
    var cover = absoluteImage(model.snapshotUrl || model.previewUrlThumbBig || model.previewUrlThumbSmall || model.avatarUrl || model.previewUrl || model.image);
    var avatar = absoluteImage(model.avatarUrl || model.previewUrlThumbSmall || cover);
    var viewers = model.viewersCount !== undefined ? model.viewersCount : model.viewers;
    return {
      userName: username,
      roomTitle: username + " 的直播",
      roomCover: cover,
      userHeadImg: avatar,
      liveState: publicLive(model) ? "1" : "0",
      userId: username,
      roomId: modelId || username,
      liveWatchedCount: viewers === undefined || viewers === null ? "" : String(viewers)
    };
  }

  function primaryTag(tag) {
    var value = String(tag || "girls").split("/")[0].toLowerCase();
    return ["girls", "couples", "men", "trans"].indexOf(value) >= 0 ? value : "girls";
  }

  var tagKeyCache = {};

  async function tagKey(tag) {
    if (String(tag).indexOf("/") < 0) return "";
    if (tagKeyCache[tag]) return tagKeyCache[tag];
    var path = "/api/front/v2/models?primaryTag=" + encodeURIComponent(primaryTag(tag))
      + "&limit=24&topLimit=61&favoritesLimit=24&msBlock=true&removeShows=true&nic=true&uniq=" + Date.now().toString(36);
    var blocks = payload(await currentAPI(path, 20)).blocks || [];
    for (var i = 0; i < blocks.length; i += 1) {
      if (String(blocks[i] && blocks[i].url || "") === String(tag)) {
        var id = String(blocks[i].tagId || "");
        var key = id.indexOf(".") >= 0 ? id.split(".").pop() : id;
        if (key) tagKeyCache[tag] = key;
        return key;
      }
    }
    return "";
  }

  async function fetchModels(tag, page) {
    page = Math.max(1, Number(page) || 1);
    var offset = (page - 1) * PAGE_SIZE;
    var key = await tagKey(tag);
    var parts = [
      "removeShows=true", "recInFeatured=false", "limit=" + PAGE_SIZE, "offset=" + offset,
      "primaryTag=" + encodeURIComponent(primaryTag(tag)), "sortBy=stripRanking", "userRole=user",
      "nic=true", "byw=false", "rcmGrp=N", "rbCnGr=true", "iem=true", "decMb=true",
      "ctryTop=true", "mlfv=false", "rectf=false", "eab=false", "sac=false"
    ];
    if (key) {
      parts.push("filterGroupTags=" + encodeURIComponent(JSON.stringify([[key]])));
      parts.push("parentTag=" + encodeURIComponent(key));
    }
    parts.push("uniq=" + Date.now().toString(36));
    var root = payload(await currentAPI("/api/front/models?" + parts.join("&"), 20));
    var models = root.models || root.items || root.users || root.results || [];
    return models.map(normalizeModel).filter(publicLive);
  }

  function currentCam(value, username) {
    var root = payload(value);
    var user = root.user && root.user.user && typeof root.user.user === "object" ? root.user.user
      : root.user && typeof root.user === "object" ? root.user
        : root.model && typeof root.model === "object" ? root.model : {};
    var cam = root.cam && typeof root.cam === "object" ? root.cam : {};
    var model = {};
    Object.keys(cam).forEach(function (key) { model[key] = cam[key]; });
    Object.keys(user).forEach(function (key) { model[key] = user[key]; });
    if (!model.username) model.username = username;
    return model;
  }

  async function fetchCam(username) {
    var name = String(username || "").trim();
    if (!name) throw Host.makeError("INVALID_ARGUMENT", "缺少主播用户名", {});
    var path = "/api/front/v2/models/username/" + encodeURIComponent(name) + "/cam?triggerRequest=loadCam&uniq=" + Date.now().toString(36);
    return currentCam(await currentAPI(path, 20), name);
  }

  function streamName(model) {
    var values = [model && model.streamName, model && model.stream_name,
      model && model.cam && model.cam.streamName, model && model.stream && model.stream.streamName];
    for (var i = 0; i < values.length; i += 1) if (String(values[i] || "").trim()) return String(values[i]).trim();
    return "";
  }

  function joinURL(base, value) {
    if (/^https?:\/\//i.test(value)) return value;
    if (String(value).indexOf("//") === 0) return "https:" + value;
    var origin = String(base).match(/^(https?:\/\/[^/]+)/i);
    if (String(value).indexOf("/") === 0) return (origin ? origin[1] : "") + value;
    return String(base).replace(/[^/]*(?:\?.*)?$/, "") + value;
  }

  function variants(text, base) {
    var lines = String(text || "").split(/\r?\n/), result = [];
    for (var i = 0; i < lines.length; i += 1) {
      var line = lines[i].trim();
      if (!/^#EXT-X-STREAM-INF:/i.test(line)) continue;
      var bandwidth = Number((line.match(/BANDWIDTH=(\d+)/i) || [])[1] || 0);
      var name = (line.match(/NAME="([^"]+)"/i) || line.match(/NAME=([^,]+)/i) || [])[1] || "";
      var resolution = line.match(/RESOLUTION=(\d+)x(\d+)/i);
      var height = Number(resolution && resolution[2] || 0), uri = "";
      for (var j = i + 1; j < lines.length; j += 1) {
        var candidate = lines[j].trim();
        if (candidate && candidate.charAt(0) !== "#") { uri = joinURL(base, candidate); break; }
      }
      if (uri && !/blurred/i.test(name)) result.push({ name: name, height: height, bandwidth: bandwidth, url: uri });
    }
    return result;
  }

  function append(url, name, value) {
    if (new RegExp("[?&]" + name + "=", "i").test(url)) return url;
    return url + (url.indexOf("?") >= 0 ? "&" : "?") + name + "=" + encodeURIComponent(value);
  }

  function playableURL(url, pkey) {
    // Keep the exact CDN host and path returned by Stripchat's signed master.
    // Rewriting b-hls-* to another CDN breaks TLS/routing in Angel Live and can
    // also detach the pkey from the network context that issued it.
    var result = String(url);
    result = append(result, "playlistType", "lowLatency");
    result = append(result, "psch", "v2");
    return append(result, "pkey", pkey);
  }

  function localHeaders() {
    return { "Accept": "application/vnd.apple.mpegurl, application/x-mpegURL, */*" };
  }

  // 直接用 index.json 当健康检查：省掉一次 /health 往返，能播时只发一个请求。
  async function proxyQualitiesAt(candidate, streamId) {
    var url = candidate.base + "/play/" + encodeURIComponent(streamId) + "/index.json";
    var response = await Host.http.request({
      request: { url: url, method: "GET", headers: { "Accept": "application/json" }, timeout: candidate.timeout || 5 }
    });
    if (!response || Number(response.status || 0) !== 200) {
      throw Host.makeError("PROXY", "Mouflon 解密代理无响应 (HTTP " + String(response && response.status || 0) + ")", { url: url });
    }
    var data = null;
    try { data = JSON.parse(String(response.bodyText || "")); }
    catch (_) { throw Host.makeError("PROXY", "Mouflon 解密代理返回了无效 JSON", { url: url }); }
    var variants = data && data.variants || [];
    if (!variants.length) throw Host.makeError("PROXY", "Mouflon 解密代理未返回可用画质", { url: url });
    return variants.map(function (item) {
      return { title: item.title || item.name || "自动", qn: item.height || 0, url: item.url, local: true };
    }).sort(function (a, b) { return b.qn - a.qn; });
  }

  async function proxyQualities(streamId) {
    // 命中过的代理排在最前，其余按配置顺序兜底。
    var order = [];
    if (proxyBaseCache) order.push(proxyBaseCache);
    for (var i = 0; i < PROXY_HOSTS.length; i += 1) {
      if (!proxyBaseCache || PROXY_HOSTS[i].base !== proxyBaseCache.base) order.push(PROXY_HOSTS[i]);
    }
    var last = null;
    for (var j = 0; j < order.length; j += 1) {
      try {
        var list = await proxyQualitiesAt(order[j], streamId);
        proxyBaseCache = order[j];
        return list;
      } catch (error) {
        last = error;
        if (proxyBaseCache && order[j].base === proxyBaseCache.base) proxyBaseCache = null;
      }
    }
    throw last || Host.makeError("PROXY", "Mouflon 解密代理不可达", {});
  }

  // cam 接口（/api/front/v2/models/username/<name>/cam）经常被 Stripchat 的反爬拦截，
  // 实测会稳定返回 HTTP 418。以前只要这个接口失败，getLiveState 就直接上报 "0"，
  // 宿主拿到 "0" 会认为主播已经下播，把正在播放的流掐掉——表现就是画面播着播着
  // 突然冻住不动，"打开前两个直播间正常、切到第三个就开始卡"也是同一个原因
  // （轮询下播的时机不同而已）。
  //
  // 现在改成：宿主说在播就直接确认；只要有任何不确定，就用云端解密代理去探真实清单
  // （探得到 = 在播），谁都问不到时返回 "3"（未知），交给宿主的 liveStateFailureFallback
  // 处理，绝不会把正在播的流误判成下播。
  var LIVE_STATE_DEADLINE_MS = 6000;

  async function proxyLiveStateAt(candidate, streamId) {
    var url = candidate.base + "/play/" + encodeURIComponent(streamId) + "/index.json";
    try {
      var response = await Host.http.request({
        request: { url: url, method: "GET", headers: { "Accept": "application/json" }, timeout: candidate.timeout || 5 }
      });
      var status = Number(response && response.status || 0);
      if (status === 200) return "1";
      // 代理可达但拿不到清单：4 个 CDN 域名都试过仍失败，按已下播算。
      if (status === 404 || status === 502) return "0";
      return "3";
    } catch (_) {
      // 连代理都连不上，属于"不知道"，不能当成下播。
      return "3";
    }
  }

  async function probeLiveViaProxy(streamId) {
    if (!streamId) return "3";
    var order = [];
    if (proxyBaseCache) order.push(proxyBaseCache);
    for (var i = 0; i < PROXY_HOSTS.length; i += 1) {
      if (!proxyBaseCache || PROXY_HOSTS[i].base !== proxyBaseCache.base) order.push(PROXY_HOSTS[i]);
    }
    for (var j = 0; j < order.length; j += 1) {
      var state = await proxyLiveStateAt(order[j], streamId);
      if (state !== "3") return state;
    }
    return "3";
  }

  async function qualitiesFor(streamId) {
    var cached = failureCache[streamId];
    if (cached && Date.now() - cached.at < FAIL_TTL_MS) throw cached.error;
    try {
      return await withDeadline(resolveQualities(streamId), RESOLVE_DEADLINE_MS,
        "解析直播地址超过 " + Math.round(RESOLVE_DEADLINE_MS / 1000) + " 秒，已中止（主播可能刚开播或网络受限）");
    } catch (error) {
      failureCache[streamId] = { at: Date.now(), error: error };
      throw error;
    }
  }

  async function resolveQualities(streamId) {
    var last = null;
    try { return await proxyQualities(streamId); }
    catch (error) { last = error; }
    try { return await discover(streamId); }
    catch (error) { last = error; }
    throw last || Host.makeError("UPSTREAM", "没有可用的 Stripchat 线路", { streamId: streamId });
  }

  async function discoverAt(host, streamId) {
    var master = "https://" + host + "/hls/" + streamId + "/master/" + streamId + "_auto.m3u8";
    var text = await get(master, hlsHeaders(), 5);
    var match = text.match(/#EXT-X-MOUFLON:PSCH:v2:([^\r\n]+)/i);
    if (!match) throw Host.makeError("UPSTREAM", "master 未返回 pkey", { host: host });
    var pkey = String(match[1]).trim().split(/\s+/)[0];
    var list = variants(text, master);
    if (!list.length) throw Host.makeError("UPSTREAM", "master 未返回画质", { host: host });
    return list.map(function (item) {
      var title = item.height ? String(item.height) + "p" : item.name || "自动";
      return { title: title, qn: item.height || 0, url: playableURL(item.url, pkey) };
    }).sort(function (a, b) { return b.qn - a.qn; });
  }

  async function discover(streamId) {
    var hosts = [
      "edge-hls.doppiocdn.org",
      "edge-hls.doppiocdn.com",
      "edge-hls.doppiocdn.media"
    ];
    // 三个 CDN 域名并发探，最坏耗时从 30 秒降到一次超时。
    return await firstSuccess(hosts.map(function (host) {
      return function () { return discoverAt(host, streamId); };
    }), Host.makeError("UPSTREAM", "无法获取 Stripchat HLS", { streamId: streamId }));
  }

  async function resolveRoom(roomId, userId) {
    var username = String(userId || "").trim();
    if (username) return await fetchCam(username);
    return { id: roomId, username: roomId, status: "public", isLive: true };
  }

  function parseShare(value) {
    var text = String(value || "");
    var match = text.match(/(?:https?:\/\/)?(?:[a-z]+\.)?stripchat\.(?:com|global)\/([^\s/?#]+)/i);
    return match ? decodeURIComponent(match[1]) : text.trim().replace(/^@/, "");
  }

  globalThis.LiveParsePlugin = {
    apiVersion: 1,

    getCategories: function () {
      return [{
        id: "stripchat",
        title: "Stripchat",
        icon: "play.tv",
        biz: "public",
        subList: CATEGORIES.map(function (item) {
          return { id: item.id, parentId: "stripchat", title: item.title, icon: item.icon, biz: item.tag };
        })
      }];
    },

    getRooms: async function (input) {
      var tag = String(input && (input.biz || input.id) || "girls");
      var models = await fetchModels(tag, input && input.page || 1);
      return models.map(roomDTO);
    },

    search: async function (input) {
      var keyword = String(input && input.keyword || "").trim().toLowerCase();
      if (!keyword) return [];
      var groups = ["girls", "couples", "men"], all = [];
      var page = input && input.page || 1;
      // 三组并发拉取，串行的话要等三个 API 往返。
      var results = await Promise.all(groups.map(function (group) {
        return fetchModels(group, page).catch(function () { return []; });
      }));
      for (var i = 0; i < results.length; i += 1) all = all.concat(results[i]);
      var seen = {};
      return all.filter(function (model) {
        var name = String(model.username || model.name || model.nickname || "").toLowerCase();
        var id = String(model.id !== undefined ? model.id : model.modelId || name);
        if (seen[id] || name.indexOf(keyword) < 0) return false;
        seen[id] = true; return true;
      }).map(roomDTO);
    },

    getRoomDetail: async function (input) {
      var model = await resolveRoom(input && input.roomId, input && input.userId);
      return roomDTO(model);
    },

    getLiveState: async function (input) {
      var roomId = String(input && input.roomId || "").trim();
      var username = String(input && input.userId || "").trim();
      try {
        var model = await withDeadline(resolveRoom(roomId, username), LIVE_STATE_DEADLINE_MS,
          "直播状态查询超过 " + Math.round(LIVE_STATE_DEADLINE_MS / 1000) + " 秒");
        if (publicLive(model)) return { liveState: "1" };
      } catch (_) { /* cam 被反爬拦截或超时，下面用代理判断，绝不因此报"已下播" */ }
      // cam 明确说不在播、或 cam 根本问不到时，都以云端代理探测到的真实清单为准。
      return { liveState: await probeLiveViaProxy(roomId || username) };
    },

    getPlayback: async function (input) {
      var roomId = String(input && input.roomId || "").trim();
      var username = String(input && input.userId || "").trim();
      if (!roomId && !username) throw Host.makeError("INVALID_ARGUMENT", "缺少直播流 ID", {});

      // 列表返回的 roomId 就是通常可用的流 ID。先直接解析，避免播放强依赖
      // Stripchat cam API；只有 roomId 过期/不匹配时才用用户名查询新流 ID。
      var qualitys = null;
      var directError = null;
      if (roomId) {
        try { qualitys = await qualitiesFor(roomId); }
        catch (error) { directError = error; }
      }
      if (!qualitys && username) {
        try {
          var model = await fetchCam(username);
          if (!publicLive(model)) throw Host.makeError("NOT_LIVE", "主播当前不是公开直播", { username: username });
          var currentStreamId = streamName(model);
          if (!currentStreamId) throw Host.makeError("NOT_LIVE", "主播当前没有可用直播流", { username: username });
          qualitys = await qualitiesFor(currentStreamId);
        } catch (fallbackError) {
          throw directError || fallbackError;
        }
      }
      if (!qualitys) throw directError || Host.makeError("NOT_LIVE", "没有可用直播流", { roomId: roomId });
      return [{
        cdn: "stripchat-official",
        displayName: "Stripchat 官方线路",
        requestContext: { roomId: roomId, userId: username },
        qualitys: qualitys.map(function (quality) {
          return {
            roomId: roomId,
            title: quality.title,
            qn: quality.qn,
            url: quality.url,
            liveCodeType: "m3u8",
            liveType: "stripchat",
            userAgent: UA,
            headers: quality.local ? localHeaders() : playbackHeaders(),
            requestContext: { roomId: roomId, userId: username },
            // avPlayer 是唯一稳定跑通的引擎：它用 HTTP/2、按原样请求分片地址。
            // mePlayer 会把分片 URL 截断（约 190 字符上限），拿不到 u 参数就一路 400，
            // 重试 8 次后整个播放线程卡死，表现就是"播一两分钟后画面卡住不动"。
            // 同时不要声明 lowLatency：低延迟模式只留 2~3 秒缓冲，任何抖动都会直接断流。
            playbackHints: {
              streamFormat: "hlsLive",
              preferredEngines: ["avPlayer"],
              isLive: true,
              requiresCustomSegmentLoader: false,
              selectionBehavior: "direct"
            }
          };
        })
      }];
    },

    resolveShare: async function (input) {
      var username = parseShare(input && input.shareCode);
      if (!username) throw Host.makeError("INVALID_ARGUMENT", "无法识别 Stripchat 分享链接", {});
      return roomDTO(await fetchCam(username));
    }
  };
})();
